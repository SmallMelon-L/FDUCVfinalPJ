import torch
import cv2
import json
import numpy as np
import os
os.environ['YOLO_VERBOSE'] = str(False)
from ultralytics import YOLO

# Set the path to the model
model_path = '/project/train/models/s402/weights/best.pt'
model_path1 = '/project/train/models/s80/weights/best.engine'
names = ['long_term_parking_restriction_lifted','yield_to_oncoming_traffic','restricted_parking_area_lifted','no_through_and_left_turn','no_long_term_parking','no_through_and_right_turn','no_parking_area','turn_left_or_right','no_passage','through_and_left_turn','no_entry_for_large_passenger_vehicles','roundabout_traffic','u_turn_allowed','no_through','drive_on_the_left_side_of_the_median_strip','motor_vehicle_lane','through_and_right_turn','left_turn','stop_and_yield','no_u_turn','u_turn_lane','no_left_and_right_turn','no_entry','no_entry_for_vehicles_transporting_dangerous_goods','slow_down_and_yield','motor_vehicle_movement','overtaking_allowed','no_entry_for_freight_vehicles','right_turn','combined_u_turn_and_left_turn_lane','no_overtaking','pedestrian_crossing','no_entry_for_motor_vehicles','combined_through_and_left_turn_lane','no_right_turn','combined_through_and_right_turn_lane','drive_on_the_right_side_of_the_median_strip','bus_lane','no_left_turn','straight_ahead','no_parking','right_turn_lane','left_turn_lane','through_lane','other']

def init():
    # Load the model
    # model = YOLO(model_path)
    # model.export(format='engine',half=True,device=0)
    model = YOLO(model_path1)
    for i in range(1, 2000):
        model('/project/train/models/s80/train_batch0.jpg',conf=0.5,iou=0.7)
    return model

def process_image(handle, input_image, args=None):
    with torch.no_grad():
        results = handle(input_image, conf=0.5, iou=0.7)

    # 处理检测结果
    result = {"model_data": {"objects": []}}
    for box in results[0].boxes.boxes:  # 遍历每个边界框
        xmin, ymin, xmax, ymax, conf, cls = box  # 解包每行
        result['model_data']['objects'].append({
            "name": names[int(cls.item())],
            "x": int(xmin.item()),
            "y": int(ymin.item()),
            "width": int(xmax.item() - xmin.item()),
            "height": int(ymax.item() - ymin.item()),
            "confidence": conf.item(),
        })
    return json.dumps(result, indent=4)



if __name__ == '__main__':
    # Test the API
    img = cv2.imread('/home/data/2814/ZDStraffic_sign20231013_V2_sample_street_1_452.jpg')
    model = init()
    import time
    s = time.time()
    result = process_image(model, img)
    e = time.time()
    print(result)
    print(f'Processing time: {e - s} seconds')
