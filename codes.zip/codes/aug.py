import cv2
import numpy as np


def random_color_jitter(image, strength=0.5):
    jitter = np.random.randint(-10, 10, image.shape) * strength
    jitter = jitter.astype(np.uint8)
    jittered_image = cv2.add(image, jitter)
    jittered_image = np.clip(jittered_image, 0, 255)
    return jittered_image


def darken_image(image, brightness_factor=-0.5, contrast_factor=0.8):
    ycrcb_image = cv2.cvtColor(image, cv2.COLOR_BGR2YCrCb)
    channels = cv2.split(ycrcb_image)

    channels = list(channels)

    channels[0] = cv2.addWeighted(
        channels[0], contrast_factor, channels[0], 0, brightness_factor * 100
    )

    merged = cv2.merge(channels)
    darkened_image = cv2.cvtColor(merged, cv2.COLOR_YCrCb2BGR)
    return darkened_image


def add_rain_effect(image, rain_density=100, rain_width=2, rain_length=15):
    overlay = image.copy()
    for _ in range(rain_density):
        x = np.random.randint(0, image.shape[1])
        y = np.random.randint(0, image.shape[0])
        cv2.line(
            overlay,
            (x, y),
            (x + rain_length, y - rain_length),
            (255, 255, 255),
            rain_width,
        )

    return cv2.addWeighted(overlay, 0.5, image, 0.5, 0)


def add_fog_effect(image, fog_intensity=0.6):
    fog_layer = np.full(image.shape, (255, 255, 255), dtype=np.uint8)
    return cv2.addWeighted(image, 1 - fog_intensity, fog_layer, fog_intensity, 0)


"""
def apply_perspective_transform(image, target_range, target_width, target_height):
    h, w = image.shape[:2]

    target_range = np.array(target_range) * np.array([w, h, w, h])
    target_range = target_range.astype(int)
    x_min, y_min, x_max, y_max = target_range

    pts_src = np.array([[x_min, y_min], [x_max, y_min], [x_max, y_max], [x_min, y_max]])

    pts_dst = np.array(
        [[0, 0], [target_width, 0], [target_width, target_height], [0, target_height]]
    )

    matrix = cv2.getPerspectiveTransform(
        pts_src.astype(np.float32), pts_dst.astype(np.float32)
    )

    transformed_image = cv2.warpPerspective(
        image, matrix, (target_width, target_height)
    )

    return transformed_image
"""


def change_viewpoint(image, angle=30, scale=1.0):
    h, w = image.shape[:2]
    center = (w // 2, h // 2)

    M = cv2.getRotationMatrix2D(center, angle, scale)

    rotated_image = cv2.warpAffine(image, M, (w, h))

    return rotated_image


def apply_perspective_transform(image, target_range, target_width, target_height, bbox):
    h, w = image.shape[:2]

    target_range_scaled = np.array(target_range) * np.array([w, h, w, h])
    target_range_scaled = target_range_scaled.astype(int)
    bbox_scaled = np.array(bbox) * np.array([w, h, w, h])
    bbox_scaled = bbox_scaled.astype(int)

    x_min, y_min, x_max, y_max = target_range_scaled
    pts_src = np.array([[x_min, y_min], [x_max, y_min], [x_max, y_max], [x_min, y_max]])

    pts_dst = np.array(
        [[0, 0], [target_width, 0], [target_width, target_height], [0, target_height]]
    )

    matrix = cv2.getPerspectiveTransform(
        pts_src.astype(np.float32), pts_dst.astype(np.float32)
    )

    transformed_image = cv2.warpPerspective(
        image, matrix, (target_width, target_height)
    )

    bbox_points = np.array(
        [
            [bbox_scaled[0], bbox_scaled[1]],
            [bbox_scaled[2], bbox_scaled[1]],
            [bbox_scaled[2], bbox_scaled[3]],
            [bbox_scaled[0], bbox_scaled[3]],
        ]
    )
    transformed_bbox_points = cv2.perspectiveTransform(
        np.array([bbox_points], dtype=np.float32), matrix
    )[0]

    x_min_new, y_min_new = np.min(transformed_bbox_points, axis=0)
    x_max_new, y_max_new = np.max(transformed_bbox_points, axis=0)

    new_bbox = np.array([x_min_new, y_min_new, x_max_new, y_max_new]) / np.array(
        [target_width, target_height, target_width, target_height]
    )

    return transformed_image, new_bbox
