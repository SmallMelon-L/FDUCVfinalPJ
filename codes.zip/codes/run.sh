#run.sh
# yolo export model=/project/train/models/n40/weights/best.pt half=True format=engine device=0

#run.sh
rm -r /project/train/src_repo/dataset
#创建数据集相关文件夹
mkdir /project/train/src_repo/dataset
mkdir /project/train/src_repo/dataset/Annotations
mkdir /project/train/src_repo/dataset/images
mkdir /project/train/src_repo/dataset/ImageSets
mkdir /project/train/src_repo/dataset/labels
mkdir /project/train/src_repo/dataset/ImageSets/Main

# python /project/train/src_repo/copytosrc.py

# cp /home/data/2814/*.xml /project/train/src_repo/dataset/Annotations
# cp /home/data/2814/*.jpg /project/train/src_repo/dataset/images
# cp /home/data/2863/*.xml /project/train/src_repo/dataset/Annotations
# cp /home/data/2863/*.jpg /project/train/src_repo/dataset/images
# cp /home/data/2868/*.xml /project/train/src_repo/dataset/Annotations
# cp /home/data/2868/*.jpg /project/train/src_repo/dataset/images

find /home/data/2814/ -name "*.xml" -exec cp {} /project/train/src_repo/dataset/Annotations \;
find /home/data/2814/ -name "*.jpg" -exec cp {} /project/train/src_repo/dataset/images \;
find /home/data/2863/ -name "*.xml" -exec cp {} /project/train/src_repo/dataset/Annotations \;
find /home/data/2863/ -name "*.jpg" -exec cp {} /project/train/src_repo/dataset/images \;
find /home/data/2868/ -name "*.xml" -exec cp {} /project/train/src_repo/dataset/Annotations \;
find /home/data/2868/ -name "*.jpg" -exec cp {} /project/train/src_repo/dataset/images \;

#执行数据集划分、转换
python /project/train/src_repo/split_train_val.py --xml_path /project/train/src_repo/dataset/Annotations --txt_path /project/train/src_repo/dataset/ImageSets/Main
cp /project/train/src_repo/voc_label.py /project/train/src_repo/dataset
python /project/train/src_repo/dataset/voc_label.py

yolo task=detect mode=train model=/project/train/models/s402/weights/best.pt data=/project/train/src_repo/data.yaml epochs=40 imgsz=640 project=/project/train/models optimizer=SGD name=s120 cos_lr=True
# yolo task=detect mode=train model=/project/train/models/n60/weights/last.pt data=/project/train/src_repo/data.yaml epochs=100 imgsz=640 project=/project/train/models optimizer=SGD name=n160 cos_lr=True batch=32 save_period=1
yolo export model=/project/train/models/s120/weights/best.pt format=engine half=True device=0