import xml.etree.ElementTree as ET
import os
from os import listdir, getcwd
from os.path import join
import random
import aug
import cv2

sets = ["train", "val", "test"]
classes = [
    "long_term_parking_restriction_lifted",
    "yield_to_oncoming_traffic",
    "restricted_parking_area_lifted",
    "no_through_and_left_turn",
    "no_long_term_parking",
    "no_through_and_right_turn",
    "no_parking_area",
    "turn_left_or_right",
    "no_passage",
    "through_and_left_turn",
    "no_entry_for_large_passenger_vehicles",
    "roundabout_traffic",
    "u_turn_allowed",
    "no_through",
    "drive_on_the_left_side_of_the_median_strip",
    "motor_vehicle_lane",
    "through_and_right_turn",
    "left_turn",
    "stop_and_yield",
    "no_u_turn",
    "u_turn_lane",
    "no_left_and_right_turn",
    "no_entry",
    "no_entry_for_vehicles_transporting_dangerous_goods",
    "slow_down_and_yield",
    "motor_vehicle_movement",
    "overtaking_allowed",
    "no_entry_for_freight_vehicles",
    "right_turn",
    "combined_u_turn_and_left_turn_lane",
    "no_overtaking",
    "pedestrian_crossing",
    "no_entry_for_motor_vehicles",
    "combined_through_and_left_turn_lane",
    "no_right_turn",
    "combined_through_and_right_turn_lane",
    "drive_on_the_right_side_of_the_median_strip",
    "bus_lane",
    "no_left_turn",
    "straight_ahead",
    "no_parking",
    "right_turn_lane",
    "left_turn_lane",
    "through_lane",
    "other",
]
valid_classes = classes[6:]
aug_classes = valid_classes[:-4]

abs_path = os.getcwd()


def convert(size, box):
    dw = 1.0 / (size[0])
    dh = 1.0 / (size[1])
    x = (box[0] + box[1]) / 2.0
    y = (box[2] + box[3]) / 2.0
    w = box[1] - box[0]
    h = box[3] - box[2]
    x = x * dw
    w = w * dw
    y = y * dh
    h = h * dh
    return (x, y, w, h)


def convert_annotation(image_id):
    in_file = open("/project/train/src_repo/dataset/Annotations/%s.xml" % (image_id))
    out_file = open("/project/train/src_repo/dataset/labels/%s.txt" % (image_id), "w")
    tree = ET.parse(in_file)
    root = tree.getroot()
    size = root.find("size")
    w = int(size.find("width").text)
    h = int(size.find("height").text)
    augflag = False

    for obj in root.iter("object"):
        cls = obj.find("name").text
        if cls not in valid_classes:
            continue
        if cls in valid_classes[:-3]:
            augflag = True
        cls_id = classes.index(cls)
        xmlbox = obj.find("bndbox")
        b = (
            float(xmlbox.find("xmin").text),
            float(xmlbox.find("xmax").text),
            float(xmlbox.find("ymin").text),
            float(xmlbox.find("ymax").text),
        )
        bb = convert((w, h), b)
        out_file.write(str(cls_id) + " " + " ".join([str(a) for a in bb]) + "\n")
    return augflag


def decide_perspective(x, y, w, h):
    xmin, xmax = x - w / 2, x + w / 2
    ymin, ymax = y - h / 2, y + h / 2
    bb = [xmin, xmax, ymin, ymax]
    nymin = 0
    nymax = min(ymax + 0.05, 1)
    dx = nymax = nymin
    if xmax > 0.5:
        nxmax = min(xmax + 0.05, 1)
        nxmin = max(nxmax - dx, 0)
    else:
        nxmin = max(xmin - 0.05, 0)
        nxmax = min(nxmin + dx, 1)
    target_range = [nxmin, nxmax, nymin, nymax]
    return bb, target_range


def copy_aug(image_id, list_file):
    if random.random() > 0.5:
        image = cv2.imread("/project/train/src_repo/dataset/images/%s.jpg" % (image_id))
        transform = aug.darken_image()
        list_file.write(
            "/project/train/src_repo/dataset/images/%s_aug.jpg\n" % (image_id)
        )
        cv2.imwrite(
            "/project/train/src_repo/dataset/images/%s_aug.jpg" % (image_id),
            transform(image),
        )
        os.system(
            "cp /project/train/src_repo/dataset/labels/%s.txt /project/train/src_repo/dataset/labels/%s_aug.txt"
        )
    else:
        image = cv2.imread("/project/train/src_repo/dataset/images/%s.jpg" % (image_id))
        transform = aug.apply_perspective_transform()
        labelf = open("/project/train/src_repo/dataset/labels/%s.txt" % (image_id))
        target_objects = labelf.readlines()
        for i, target_object in enumerate(target_objects):
            cls, x, y, w, h = target_object.split(" ")
            cls = int(cls)
            x, y, w, h = float(x), float(y), float(w), float(h)
            if cls in range(7, 40):
                bb, target_range = decide_perspective(x, y, w, h)
                nimage, nbb = transform(image, target_range, 640, 640, bb)
                list_file.write(
                    "/project/train/src_repo/dataset/images/%s_p%d.jpg\n"
                    % (image_id, i)
                )
                cv2.imwrite(
                    "/project/train/src_repo/dataset/images/%s_p%d.jpg" % (image_id, i),
                    nimage,
                )
                nlabelf = open(
                    "/project/train/src_repo/dataset/labels/%s_p%d}.txt"
                    % (image_id, i),
                    "w",
                )
                nlabelf.write(str(cls) + " " + " ".join([str(a) for a in nbb]))


for image_set in sets:
    if not os.path.exists("/project/train/src_repo/dataset/labels/"):
        os.makedirs("/project/train/src_repo/dataset/labels/")
    image_ids = [
        id
        for id in open(
            "/project/train/src_repo/dataset/ImageSets/Main/%s.txt" % image_set
        )
        .read()
        .strip()
        .split("\n")
        if id
    ]
    list_file = open("/project/train/src_repo/dataset/%s.txt" % (image_set), "w")
    for image_id in image_ids:
        list_file.write("/project/train/src_repo/dataset/images/%s.jpg\n" % (image_id))
        flag = convert_annotation(image_id)
        if image_set == "train" and (flag or random.random() < 0.1):
            copy_aug(image_id, list_file)
    list_file.close()
